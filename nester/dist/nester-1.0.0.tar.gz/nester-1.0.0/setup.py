from distutils.core import setup

setup(
		name			= 'nester',
		version			= '1.0.0',
		py_modules		= ['nester'],
		author			= 'chengxq',
		author_email	= '815292858@qq.com',
		url				= '',
		description		= 'A simple printer of nested lists',
)
